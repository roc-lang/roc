# Windows systems

Windows support is limited. Until that is here we recommend using [Ubuntu 22.04](https://apps.microsoft.com/detail/9pn20msr04dw?hl=en-us&gl=US) through the "Windows Subsystem for Linux" (WSL).

Once you're inside Ubuntu, [install Roc](/install/linux_x86_64).
