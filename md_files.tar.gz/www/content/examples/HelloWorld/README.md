# Hello, World!

Printing [Hello World](https://en.wikipedia.org/wiki/%22Hello,_World!%22_program) to the command line using the [basic-cli platform](https://github.com/roc-lang/basic-cli):

## Code
```roc
file:main.roc
```

## Output

Run this from the directory that has `main.roc` in it:

```
$ roc main.roc
Hello, World!
```
