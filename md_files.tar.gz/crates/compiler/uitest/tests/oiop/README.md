Tests for open-in-output-position semantics.
