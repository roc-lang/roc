# Algorithm examples

To run:

```bash
cargo run fibonacci.roc
cargo run quicksort.roc
```

To run in release mode instead, do:

```bash
cargo run --release fibonacci.roc
cargo run --release quicksort.roc
```
